/*
 * MLC_Aero_Simulink3_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MLC_Aero_Simulink3".
 *
 * Model version              : 1.115
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Fri Apr 18 19:10:52 2025
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MLC_Aero_Simulink3.h"
#include "MLC_Aero_Simulink3_private.h"

/* Block parameters (default storage) */
P_MLC_Aero_Simulink3_T MLC_Aero_Simulink3_P = {
  /* Mask Parameter: Green_color
   * Referenced by: '<S17>/Constant'
   */
  { 0.0, 1.0, 0.0 },

  /* Mask Parameter: Yellow_color
   * Referenced by: '<S19>/Constant'
   */
  { 1.0, 1.0, 0.0 },

  /* Mask Parameter: PitchBiasRemoval_end_time
   * Referenced by: '<S18>/Step: end_time'
   */
  1.0,

  /* Mask Parameter: PitchBiasRemoval_start_time
   * Referenced by: '<S18>/Step: start_time'
   */
  0.0,

  /* Mask Parameter: PitchBiasRemoval_switch_id
   * Referenced by: '<S18>/Constant'
   */
  1.0,

  /* Mask Parameter: HILReadTimebase_clock
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  0,

  /* Mask Parameter: HILReadTimebase_analog_channels
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  { 0U, 1U },

  /* Mask Parameter: HILWrite_analog_channels
   * Referenced by: '<S10>/HIL Write'
   */
  { 0U, 1U },

  /* Mask Parameter: HILReadTimebase_encoder_channel
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  { 2U, 3U },

  /* Mask Parameter: HILReadTimebase_other_channels
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  { 4000U, 4002U, 14000U, 14001U },

  /* Mask Parameter: HILWrite_other_channels
   * Referenced by: '<S10>/HIL Write'
   */
  { 11000U, 11001U, 11002U },

  /* Mask Parameter: HILReadTimebase_samples_in_buff
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  500U,

  /* Expression: 24
   * Referenced by: '<S10>/+//- 24V'
   */
  24.0,

  /* Expression: -24
   * Referenced by: '<S10>/+//- 24V'
   */
  -24.0,

  /* Computed Parameter: x_avg_n_Y0
   * Referenced by: '<S20>/x_avg_n'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S24>/unity'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S24>/Unit Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S20>/Sum( k=1,n-1, x(k) )'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S21>/zero'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S22>/Vbiased'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S23>/Vunbiased'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S18>/Step: start_time'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S18>/Step: start_time'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S18>/Step: end_time'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S18>/Step: end_time'
   */
  1.0,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<S10>/HIL Initialize'
   */
  1.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<S10>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_start
   * Referenced by: '<S10>/HIL Initialize'
   */
  1.0,

  /* Expression: set_other_outputs_at_switch_in
   * Referenced by: '<S10>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  0.0,

  /* Expression: final_other_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 1.0, 0.0, 0.0 },

  /* Expression: analog_input_maximums
   * Referenced by: '<S10>/HIL Initialize'
   */
  3.0,

  /* Expression: analog_input_minimums
   * Referenced by: '<S10>/HIL Initialize'
   */
  -3.0,

  /* Expression: analog_output_maximums
   * Referenced by: '<S10>/HIL Initialize'
   */
  24.0,

  /* Expression: analog_output_minimums
   * Referenced by: '<S10>/HIL Initialize'
   */
  -24.0,

  /* Expression: initial_analog_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_analog_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  0.0,

  /* Expression: initial_other_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0.0, 1.0, 0.0 },

  /* Expression: watchdog_other_outputs
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0.0, 0.0, 1.0 },

  /* Computed Parameter: Internal_A
   * Referenced by: '<S1>/Internal'
   */
  { -0.19239845956794188, 2.1106849098800229, 0.4812664096166045,
    0.11498527665794524, -0.35300025282354663, 0.37618505389974655,
    0.43163798784057922, 0.012473603282354029, -20.82100076215124,
    12.336503788577525, 30.256692662189486, -20.137278647079, 11.320805990423198,
    -5.1764957537089895, 0.050530924485556544, -1.253625865966161,
    -2.8472896188741093, -0.39167923000103128, 0.30325848312621267,
    -0.11263848515102459, -0.68257268205244992, -0.89029873115616731,
    -1.4044618448002508, -0.40750296011513332, 2.115302025136931,
    -0.00050183441809948455, 0.0067858476217954565, -0.0092338615579520833,
    -0.0068049606296387956, 0.0021519623282268696, -2.4450398870105716,
    -0.18458704304100579, 3.5429907814548551, 0.27089158972008709,
    1.6062405471473633, -0.011918499539893448, 0.043706419897855606,
    -0.039790430413139649, -0.10324084645484255, -0.0032599522522134016,
    -0.0016963679573983607, 0.0052091419639833884, -0.0023238794097893648,
    -0.0096821068572497462, 0.13272396843084755, 0.36972105619906159,
    -0.87555319273676158, 0.029483808146472959, -0.078044759894807567,
    0.078419928063414357, 0.099007118429837629, 0.0083495243395746155,
    -11.187131007464014, 2.8517524191983314, 16.23599222046677,
    -4.722900014833022, 6.69874351710238, -1.4043279891217628,
    0.11181119755519214, -0.43189308295422019, -1.0101006821732341,
    -0.11172572363624023, 0.0767419530189328, -0.017916478773397727,
    -0.1869345674343349, -0.25922726860353623, 0.015583699618674909,
    0.036235324667457131, 0.0256305993176816, -0.38302563478502744,
    1.1405789972740517, 0.02256400294285623, 0.025539969141727289,
    0.00059126471651511914, -1.1047805770920109, 0.73004777529171938,
    1.6043158303173135, -1.1918956075941913, 0.60385749969796942,
    -0.301505961542504, 0.0027162006428052966, -0.067020368972080913,
    -0.1520144752987764, -0.022694798478964585, 0.017768520828816251,
    -0.0068108467281410949, -0.039708318939239123, -0.051469410680943406,
    0.057741992138639828, 0.13820240138948431, 0.10027648333145235,
    -1.0999091004636889, -0.54472564758807229, 0.4132020842373193,
    1.09800695343504, 1.4129743711272049, -4.2545223884930365,
    5.6642681367337042, 6.178879675762019, -9.1031894400296274,
    2.4316381224413277, -2.7496676001737015, 0.013499062260699366,
    -0.27490378936710397, -0.618485371581937, -0.12905892276574554,
    0.081018495062483348, -0.0053076640290359092, -0.21106547236720014,
    -0.252102050318899, 0.024966328403438945, 0.058045187373223228,
    0.041055197342336, 0.010706635873465277, -0.033609759389602145,
    -0.15286067128674674, 1.4686823765574224, 0.00094861671718787788,
    -1.7697271440655709, 1.1678667256207265, 2.5699469555633816,
    -1.9066865468551741, 0.96724151878347731, -0.48241373735291304,
    0.0043502966041335661, -0.10734813517688646, -0.24348950767180624,
    -0.036314260727830831, 0.028427870852020729, -0.010892668223125219,
    -0.0635347854604953, -0.082359154444725677, 0.06568841856933369,
    0.15822595280065205, 0.11543367253749995, 0.079682493995831757,
    -0.19618476649344357, -1.2354032980446643, 0.068141748402096913,
    1.972454392380582, -4.8811824109930875, 7.2054946853694242,
    7.0891975101187761, -11.562175379298314, 2.8160934050056539,
    -3.5490412331008114, 0.016242590763436891, -0.31955719548435735,
    -0.71777691859501747, -0.15835285466920396, 0.0960075392762564,
    -0.00083869512056754247, -0.25646898241176908, -0.30245455983323144,
    0.055564975936341236, 0.13750208694049368, 0.10255973540411367,
    0.10128394219598984, -0.23700461149486349, 0.2271306767460628,
    0.31602447660242039, -1.0812319952104223, -4.2780780772120313,
    8.8181377579619529, 6.2136469691198615, -14.093888003918796,
    2.5613585878363287, -4.5016972308712369, 0.016894267036236241,
    -0.29482938092949351, -0.65811964649544163, -0.17547468728355806,
    0.095418704436371155, 0.017386312996694228, -0.27612521884175645,
    -0.31283872685939335, 1.4305419461145913E-7, 3.2965672129674615E-7,
    2.3214143136334253E-7, 5.5330915907844775E-8, -1.6975408524390342E-7,
    1.8086300487741637E-7, 2.0760570581570911E-7, 6.0337978506351843E-9,
    -0.0047240916395423259, 5.9334876026937917E-6, 1.4596127768614167E-5,
    -9.6853756473545882E-6, 5.46042911355726E-6, -2.49086849726424E-6,
    2.4367990244510073E-8, -6.0463312763510636E-7, -1.3733170585993828E-6,
    -1.8849916661951814E-7, 1.4589978561524502E-7, -5.4141767142289205E-8,
    -3.2845718706731681E-7, -4.2849157439303211E-7, -1.2655635583746084E-7,
    -2.9402995772027933E-7, -2.0789477067047169E-7, -5.3850920626127322E-8,
    1.687701055990022E-7, -1.8112621806609523E-7, -2.0524783046495958E-7,
    -4.8505693351005208E-9, 8.9641418490388042E-6, -0.0047199144095169555,
    -1.301819945540514E-5, 9.5782232977473077E-6, -4.8972937919380565E-6,
    2.42623092581674E-6, -2.2012832960489704E-8, 5.4342306920720839E-7,
    1.2327361183242995E-6, 1.8270722818655231E-7, -1.4291199026239079E-7,
    5.46358116487342E-8, 3.195675307085162E-7, 4.1444097511826162E-7,
    -0.64331420347966, -1.4821911555577181, -1.0436498837873638,
    -0.24826143392988517, 0.76125338615286209, -0.81092049667467991,
    -0.93112927948844981, -0.027189804141114937, 45.159184820085862,
    -26.612111947094792, -65.626661409354256, 43.439408615467748,
    -23.547900975644783, 11.175921642407207, -0.10953062626765281,
    2.7180569486382935, 6.1737628809587006, 0.84585311105880867,
    -0.65452542765642729, 0.24270338989722048, 1.4737495403650345,
    1.9228733966498675, 2.0735852016527874, 4.81765846475524, 3.4063651629677589,
    0.88247788449623343, -2.7658048629247811, 2.9683320718870583,
    3.3635709053170713, 0.079460315159650463, -146.87694769945634,
    96.144996192904941, 213.30219195294686, -156.96657510556568,
    80.242593346867793, -38.7597301255313, 0.36068692095002658,
    -8.9040693111747746, -20.19852192109667, -2.9940803020138791,
    2.3419845056558577, -0.89539348997179813, -5.2368858600573862,
    -6.7915490931709259, -0.99426568041628993, -2.4944681366638335,
    -1.81214689184401, -0.31512566961179794, 0.92737367848446439,
    -0.97302888693035627, -1.1454651428784262, -0.050682329224085,
    75.755243069008756, -32.8082836593276, -110.02039461081979,
    53.769880353742437, -43.147374938511021, 14.431370703713396,
    -0.45319937346340472, 3.7918154876920718, 8.70510205487694,
    1.1094396089694734, -0.82776790698527491, 0.27359918358302487,
    1.9085586167203448, 2.5386552756923377, 0.4699082468080753,
    1.1172628272368472, 0.80616019164607788, 0.43541516779106559,
    -1.120800037067833, 1.1203219264975246, 1.4473079198045404,
    0.078895310158912935, -34.323087671850082, 40.717750251214575,
    49.84811256304387, -65.558348314752891, 19.431330951682956,
    -19.430672498398245, 0.10365961231986781, -2.1883629878094291,
    -4.9317929344444424, -0.96740505774397856, 0.62986432011447868,
    -0.077496440619533508, -1.5987089582547287, -1.936071329270179,
    -1.1509006591789825, -2.6512609520361963, -1.8666799995987589,
    -0.44331274592492409, 1.358741865352181, -1.4471683125743073,
    -1.6621454342572848, -0.048725725797044817, 80.777291275739145,
    -47.5047698905046, -117.38939855924191, 77.542576605870153,
    -43.905338760341067, 19.956158732930284, -0.68474810670736252,
    6.2885376086470508, 11.041953400802385, 1.5105411856543445,
    -1.1686102373222953, 0.43305769511597858, 2.6316465573906314,
    3.434055647264318, -1.64442387642812, -3.7755615312815998,
    -2.6561000257083212, -0.6385430463100491, 1.9633678037363227,
    -2.093448186260102, -2.3997596739867966, -0.068383459717683337,
    115.06829720616753, -68.5872471844807, -167.31688477007927,
    111.95837097573575, -62.515171965368275, 28.747617366989513,
    -1.8822638050532912, 5.5361022975792586, 15.721384413660546,
    2.1743376976907558, -1.6847769046974703, 0.62717477950215417,
    3.7902332228681361, 4.9417403176664338, -0.89177538870535278,
    -2.0234393215825115, -1.4188563290326826, -0.34961134023836965,
    1.0816339950566665, -1.1557442099003961, -1.3199007276574777,
    -0.035518561797571735, 61.724605833350267, -37.725084970867478,
    -89.921753644514027, 61.583172021748382, -33.4590872974124,
    15.742570940811659, -0.54389518514151436, 1.6922393415607964,
    2.6604343258814263, 1.1888857189933701, -0.92400928771957558,
    0.34700805203264834, 2.0747059964363217, 2.7006743613383395,
    -1.1756681001187017, -2.7316056857081907, -1.9314463724284694,
    -0.50058854909989781, 1.5690749316629835, -1.6840298701554604,
    -1.9081431842182297, -0.045027352693770339, 83.2793036446265,
    -54.54278725861036, -120.94202326317931, 89.046772230663649,
    -45.498787661749532, 22.553931710912941, -0.20452289165065882,
    5.0488015217940507, 11.452925510953463, 1.3086506387420611,
    -0.16695016869867185, 0.508003882823693, 2.9706363600070596,
    3.8524105394934187, -0.72816763823613506, -1.690228486344461,
    -1.1945405782242369, -0.30541265636490766, 0.9640451253067962,
    -1.0369777760219381, -1.1699213349554145, -0.026698821323626554,
    51.527135413653639, -33.459899026541343, -74.83747511411822,
    54.679798613503131, -28.133653567042423, 13.820183528609336,
    -0.12616069724298318, 3.1211640879217124, 7.08084232718661,
    -0.61835080373743678, -0.75682495493715973, 0.31089458693210414,
    1.8197230569639802, 2.3600241321980513, -1.1327330751716955,
    -2.6319867445149825, -1.8610567566222556, -0.48259094884689574,
    1.5128492051737052, -1.6237523967205627, -1.8397079699217598,
    -0.043354752872222235, 80.242509185971343, -52.586658576964766,
    -116.53135982608389, 85.8532731354145, -43.841041623306715,
    21.743157465397889, -0.1970801274579666, 4.8649141223000312,
    11.035698675888987, 1.637267140311059, -1.2808237146821655,
    0.30089090857044837, 4.291653651678411, 3.7137691179139214,
    -0.5346261280310961, -1.2396455815319729, -0.875629284839825,
    -0.22065123895938971, 0.70069539379003931, -0.75512460323655628,
    -0.848800873017751, -0.018866167196457416, 37.788155274817015,
    -24.288225979386478, -54.888927904782015, 39.726955382852,
    -20.617999151881929, 10.024811335284511, -0.0922400864192777,
    2.2867864943432252, 5.18852387916525, 0.060354203929446348,
    0.033695591078461873, -1.5655426754811599, -0.12081133394496435,
    1.7117894601075021, -0.74939246114200231, -1.7370264842674499,
    -1.2267455657824025, -0.30787823595355762, 0.978185047245609,
    -1.0543260765847466, -1.1847433673790353, -0.026355205690918041,
    52.948498891158373, -33.9037809116138, -76.91234559269212,
    55.462202388569395, -28.883609500009587, 13.996379944985485,
    -0.12915145967452182, 3.2032674488314421, 7.2682722061592191,
    0.011186090810045846, 0.11293602319333229, -0.23083897348500648,
    -0.036792667907533216, -1.6510657254054641 },

  /* Computed Parameter: Internal_B
   * Referenced by: '<S1>/Internal'
   */
  { 2.0332387917979919, -1.8961894473134835, -0.19055260411630115,
    0.15350719611138286, 0.13758519703878319, -0.14423050890625069,
    0.10259176552781525, -0.12114683468504323, 0.28027690930809224,
    -0.3250455892372664, 0.16445086084175639, -0.19363208435859181,
    0.29321987686567508, -0.33669557513851572, 0.15588681319467654,
    -0.17504308396082574, 2.0000009820752878, -9.0991974538040336E-7,
    -8.3640487127248853E-7, 2.000000967543436, -4.4201023591342263,
    4.073281903839443, 13.703247056984303, -15.8577925165572, -4.363742927284723,
    4.0999058341177186, 2.4644355496475048, -2.8371605762658358,
    -7.9131407843767763, 7.2595977526494986, -11.407712863621395,
    10.601928938430779, -6.3943816958622248, 5.9603489755156547,
    -7.7677469272510828, 8.9991382940537541, -4.8341633380625977,
    5.6107857030220449, -7.4821948930668158, 8.6799036222303947,
    -3.5679848274767005, 4.1268759981629506, -5.009572330271534,
    5.764474813591109 },

  /* Computed Parameter: Internal_C
   * Referenced by: '<S1>/Internal'
   */
  { -2.8174998881814139, -7.9563559900517085, -6.0500417603180692,
    -2.0521577738275036, 4.7118397947927955, -4.4650486339024011,
    -6.3081979492801539, -0.52894505224356136, 242.26992495031965,
    -176.89732530219814, -340.77684345697173, 284.54030571938517,
    -145.82710134357364, 86.787017880300766, -1.1855612941111868,
    16.404907448450604, 37.699299365147432, 6.9615370130318, -4.82639521243217,
    1.174067413108502, 11.621616834803673, 15.918128663010794,
    -2.4489735887087849, -7.147235635115929, -5.4060536692958392,
    0.31445876800912215, -0.59844710066645312, 0.52287041950530366,
    0.88291905267862925, 0.0089042217604283075, 214.88786417071734,
    22.733577763947483, -298.55489862156196, -32.6704143384059,
    -126.93597803468214, -8.6933614602617215, -1.0549242508765908,
    14.02965161807824, 32.753661233912382, -0.66943198823983174,
    0.56848885409617056, -0.26166585069187759, -1.1745748298790031,
    -1.3853158659507514 },

  /* Computed Parameter: Internal_A_j
   * Referenced by: '<S11>/Internal'
   */
  { 0.33272376693407457, -1.3088362953845083, 0.41854086088053366,
    -0.61014045284737084, 0.81008818555158268, 0.16602434289885082,
    -0.41854086088053355, 0.61014045284737073, -0.8100881855515828,
    0.97678760958680655, -0.7242710916051236, -0.61014045284737084,
    0.4050440927757914, -0.48839380479340327, 0.93354152204539043,
    -0.83774172606197184, 0.22762381266502696, -1.4702510796447827,
    0.32149153440317768, -0.39524556393397942, 0.9151881398206303,
    0.32743912715912549, -0.32149153440317768, 0.39524556393397942,
    -0.9151881398206303, 0.81537282532653177, -0.82132041808247958,
    -0.39524556393397947, 0.9151881398206303, -0.81537282532653177,
    1.9641323705681368, -0.74756638855167779 },

  /* Computed Parameter: Internal_B_p
   * Referenced by: '<S11>/Internal'
   */
  { 0.254907299144324, -0.25490729914432392, 0.254907299144324,
    -0.127453649572162 },

  /* Computed Parameter: Internal_C_f
   * Referenced by: '<S11>/Internal'
   */
  { -0.17076377782879884, -0.34296678014304982, 0.14417675675696714,
    -0.60211202690495635 },

  /* Computed Parameter: Internal_D
   * Referenced by: '<S11>/Internal'
   */
  0.20015535301113432,

  /* Computed Parameter: Internal_A_j5
   * Referenced by: '<S6>/Internal'
   */
  -180.83923985432125,

  /* Computed Parameter: Internal_B_g
   * Referenced by: '<S6>/Internal'
   */
  0.1882385662534844,

  /* Computed Parameter: Internal_C_n
   * Referenced by: '<S6>/Internal'
   */
  1.5337518400048769,

  /* Computed Parameter: Internal_D_n
   * Referenced by: '<S6>/Internal'
   */
  -0.960628109978806,

  /* Computed Parameter: Internal_A_c
   * Referenced by: '<S12>/Internal'
   */
  { 0.33272376693407457, -1.3088362953845083, 0.41854086088053366,
    -0.61014045284737084, 0.81008818555158268, 0.16602434289885082,
    -0.41854086088053355, 0.61014045284737073, -0.8100881855515828,
    0.97678760958680655, -0.7242710916051236, -0.61014045284737084,
    0.4050440927757914, -0.48839380479340327, 0.93354152204539043,
    -0.83774172606197184, 0.22762381266502696, -1.4702510796447827,
    0.32149153440317768, -0.39524556393397942, 0.9151881398206303,
    0.32743912715912549, -0.32149153440317768, 0.39524556393397942,
    -0.9151881398206303, 0.81537282532653177, -0.82132041808247958,
    -0.39524556393397947, 0.9151881398206303, -0.81537282532653177,
    1.9641323705681368, -0.74756638855167779 },

  /* Computed Parameter: Internal_B_p2
   * Referenced by: '<S12>/Internal'
   */
  { 0.28640149427128164, -0.28640149427128164, 0.28640149427128175,
    -0.28640149427128175 },

  /* Computed Parameter: Internal_C_nt
   * Referenced by: '<S12>/Internal'
   */
  { -0.15315977378873172, -0.40032305723236788, 0.050547293078837749,
    -0.29794780651064851 },

  /* Computed Parameter: Internal_D_f
   * Referenced by: '<S12>/Internal'
   */
  0.17592417431019691,

  /* Computed Parameter: Internal_A_e
   * Referenced by: '<S7>/Internal'
   */
  -0.062250821981800014,

  /* Computed Parameter: Internal_B_i
   * Referenced by: '<S7>/Internal'
   */
  -1.0353087411688704,

  /* Computed Parameter: Internal_C_k
   * Referenced by: '<S7>/Internal'
   */
  -0.072887511998141558,

  /* Computed Parameter: Internal_D_b
   * Referenced by: '<S7>/Internal'
   */
  -0.74516523620333,

  /* Expression: [0 0]
   * Referenced by: '<S10>/No Control'
   */
  { 0.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S10>/Motor Enable'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/LED Colour'
   */
  0.0,

  /* Expression: [2*pi/2048 2*pi/4096]
   * Referenced by: '<S10>/Counts to rads'
   */
  { 0.0030679615757712823, 0.0015339807878856412 },

  /* Expression: pi/6
   * Referenced by: '<Root>/Pitch Reference '
   */
  0.52359877559829882,

  /* Expression: 0.02
   * Referenced by: '<Root>/Pitch Reference '
   */
  0.02,

  /* Expression: pi/4
   * Referenced by: '<Root>/Yaw Reference'
   */
  0.78539816339744828,

  /* Expression: 0.02
   * Referenced by: '<Root>/Yaw Reference'
   */
  0.02,

  /* Computed Parameter: HILInitialize_CKChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIConfiguration
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOWatchdog
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIInitial
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_AOChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_DOChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 0U, 1U, 2U, 3U },

  /* Computed Parameter: HILInitialize_EIQuadrature
   * Referenced by: '<S10>/HIL Initialize'
   */
  4U,

  /* Computed Parameter: HILInitialize_OOChannels
   * Referenced by: '<S10>/HIL Initialize'
   */
  { 11000U, 11001U, 11002U },

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOReset
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOReset
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POStart
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POEnter
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POReset
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_OOReset
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<S10>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOInitial
   * Referenced by: '<S10>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILReadTimebase_Active
   * Referenced by: '<S10>/HIL Read Timebase'
   */
  1,

  /* Computed Parameter: HILWrite_Active
   * Referenced by: '<S10>/HIL Write'
   */
  0
};
