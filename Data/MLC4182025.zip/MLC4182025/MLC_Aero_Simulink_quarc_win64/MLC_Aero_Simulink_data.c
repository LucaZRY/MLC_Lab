/*
 * MLC_Aero_Simulink_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MLC_Aero_Simulink".
 *
 * Model version              : 1.100
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Fri Apr 18 15:32:53 2025
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MLC_Aero_Simulink.h"
#include "MLC_Aero_Simulink_private.h"

/* Block parameters (default storage) */
P_MLC_Aero_Simulink_T MLC_Aero_Simulink_P = {
  /* Mask Parameter: Green_color
   * Referenced by: '<S14>/Constant'
   */
  { 0.0, 1.0, 0.0 },

  /* Mask Parameter: Yellow_color
   * Referenced by: '<S16>/Constant'
   */
  { 1.0, 1.0, 0.0 },

  /* Mask Parameter: PitchBiasRemoval_end_time
   * Referenced by: '<S15>/Step: end_time'
   */
  1.0,

  /* Mask Parameter: PitchBiasRemoval_start_time
   * Referenced by: '<S15>/Step: start_time'
   */
  0.0,

  /* Mask Parameter: PitchBiasRemoval_switch_id
   * Referenced by: '<S15>/Constant'
   */
  1.0,

  /* Mask Parameter: HILReadTimebase_clock
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  0,

  /* Mask Parameter: HILReadTimebase_analog_channels
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  { 0U, 1U },

  /* Mask Parameter: HILWrite_analog_channels
   * Referenced by: '<S7>/HIL Write'
   */
  { 0U, 1U },

  /* Mask Parameter: HILReadTimebase_encoder_channel
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  { 2U, 3U },

  /* Mask Parameter: HILReadTimebase_other_channels
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  { 4000U, 4002U, 14000U, 14001U },

  /* Mask Parameter: HILWrite_other_channels
   * Referenced by: '<S7>/HIL Write'
   */
  { 11000U, 11001U, 11002U },

  /* Mask Parameter: HILReadTimebase_samples_in_buff
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  500U,

  /* Expression: 24
   * Referenced by: '<S7>/+//- 24V'
   */
  24.0,

  /* Expression: -24
   * Referenced by: '<S7>/+//- 24V'
   */
  -24.0,

  /* Computed Parameter: x_avg_n_Y0
   * Referenced by: '<S17>/x_avg_n'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S21>/unity'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S21>/Unit Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S17>/Sum( k=1,n-1, x(k) )'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S18>/zero'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S19>/Vbiased'
   */
  0.0,

  /* Expression: [0]
   * Referenced by: '<S20>/Vunbiased'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S15>/Step: start_time'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S15>/Step: start_time'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S15>/Step: end_time'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S15>/Step: end_time'
   */
  1.0,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<S7>/HIL Initialize'
   */
  1.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<S7>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_start
   * Referenced by: '<S7>/HIL Initialize'
   */
  1.0,

  /* Expression: set_other_outputs_at_switch_in
   * Referenced by: '<S7>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  0.0,

  /* Expression: final_other_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 1.0, 0.0, 0.0 },

  /* Expression: analog_input_maximums
   * Referenced by: '<S7>/HIL Initialize'
   */
  3.0,

  /* Expression: analog_input_minimums
   * Referenced by: '<S7>/HIL Initialize'
   */
  -3.0,

  /* Expression: analog_output_maximums
   * Referenced by: '<S7>/HIL Initialize'
   */
  24.0,

  /* Expression: analog_output_minimums
   * Referenced by: '<S7>/HIL Initialize'
   */
  -24.0,

  /* Expression: initial_analog_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_analog_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  0.0,

  /* Expression: initial_other_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0.0, 1.0, 0.0 },

  /* Expression: watchdog_other_outputs
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0.0, 0.0, 1.0 },

  /* Computed Parameter: Internal_A
   * Referenced by: '<S1>/Internal'
   */
  { 0.6328812525881975, -2199.0241641237649, -1.4010982555931313E+6,
    1.5211020870802209E+6, -218525.92839219703, 164912.27724011161,
    -37221.754700007434, -454.62383644179744, -131.40908669223037,
    -2096.3367613504583, -114440.42999094067, -18219.403095275829,
    -20421.100846921006, -3801.7292996017122, -753.10308237983622,
    -8.17451128838496, -68.559083345232565, -7.7188011425184246,
    1.1036094818914663, 1.0, 1.1036094818910838, -10.707803023982098, 1.0,
    -32.110588374698573, 10.23552236783549, -0.32492547725674154,
    0.99781639653537535, 1.5766249868435169, 5.9081387842668329,
    10.100252709373583, -57.937499744461505, -1.0003608197651566,
    -2.4374699141105292, -3.8513858707970607, 6.159871085296178,
    -5.0181189086029114, 8.607442371493562, 0.6328812525881975,
    -1.4010983440240452E+6, 1.5211023029600945E+6, -218525.92839219703,
    164912.27724011161, -37221.754700007434, -2653.6480005655621,
    -131.40908669223037, -114440.45381869073, -18219.42789383345,
    -20421.100846921006, -3801.7292996017122, -753.10308237983622,
    -8.17451128838496, -2164.8958446956908 },

  /* Computed Parameter: Internal_B
   * Referenced by: '<S1>/Internal'
   */
  { -7.7188011425184246, 1.1036094818914663, 1.1036094818910838,
    -10.707803023982098, -30.398922483131372, 10.23552236783549,
    10.100252709373583, -57.937499744461505, -5.0181189086029114,
    8.607442371493562, -0.088430913910184539, 0.21587987367726427,
    -0.023827750059493294, -0.024798557618929642 },

  /* Computed Parameter: Internal_C
   * Referenced by: '<S1>/Internal'
   */
  { 19.853702358604014, 31.370343610924436, 61.576492837277065 },

  /* Computed Parameter: Internal_A_j
   * Referenced by: '<S8>/Internal'
   */
  { 0.34130996803671865, -1.3159750589977677, 0.42446948078800656,
    -0.61580482343162235, 0.80188509371645011, 0.17277999724459825,
    -0.4244694807880065, 0.61580482343162213, -0.80188509371645011,
    0.97041506450857062, -0.7187255809651627, -0.61580482343162213,
    0.40094254685822506, -0.48520753225428531, 0.93096032135916573,
    -0.83529265003735809, 0.22528086755703614, -1.4703543872522653,
    0.31989994403871386, -0.39491104850389713, 0.917914194196133,
    0.3271593254990961, -0.31989994403871386, 0.39491104850389713,
    -0.91791419419613274, 0.81603573625407289, -0.82329511771445507,
    -0.394911048503897, 0.91791419419613274, -0.81603573625407289,
    1.9664901794676242, -0.74828401324927218 },

  /* Computed Parameter: Internal_B_p
   * Referenced by: '<S8>/Internal'
   */
  { 0.25222597922290413, -0.25222597922290413, 0.252225979222904,
    -0.126112989611452 },

  /* Computed Parameter: Internal_C_f
   * Referenced by: '<S8>/Internal'
   */
  { -0.15719020149654067, -0.34495466828400717, 0.14900546331277276,
    -0.60019592690709578 },

  /* Computed Parameter: Internal_D
   * Referenced by: '<S8>/Internal'
   */
  0.1939592467803064,

  /* Computed Parameter: Internal_A_j5
   * Referenced by: '<S5>/Internal'
   */
  { -0.2255507262383866, -3.0378021552047061, 3.0378021552047061,
    -0.2255507262383866, -2.4906079103976144 },

  /* Computed Parameter: Internal_B_g
   * Referenced by: '<S5>/Internal'
   */
  { -0.25286704790728914, 0.359509123978975, -1.1197950661403682 },

  /* Computed Parameter: Internal_C_n
   * Referenced by: '<S5>/Internal'
   */
  { 0.25928563387830428, -1.0165390348522914, -0.14409186727156742 },

  /* Computed Parameter: Internal_D_n
   * Referenced by: '<S5>/Internal'
   */
  -0.014963624634357544,

  /* Computed Parameter: Internal_A_c
   * Referenced by: '<S9>/Internal'
   */
  { 0.34130996803671865, -1.3159750589977677, 0.42446948078800656,
    -0.61580482343162235, 0.80188509371645011, 0.17277999724459825,
    -0.4244694807880065, 0.61580482343162213, -0.80188509371645011,
    0.97041506450857062, -0.7187255809651627, -0.61580482343162213,
    0.40094254685822506, -0.48520753225428531, 0.93096032135916573,
    -0.83529265003735809, 0.22528086755703614, -1.4703543872522653,
    0.31989994403871386, -0.39491104850389713, 0.917914194196133,
    0.3271593254990961, -0.31989994403871386, 0.39491104850389713,
    -0.91791419419613274, 0.81603573625407289, -0.82329511771445507,
    -0.394911048503897, 0.91791419419613274, -0.81603573625407289,
    1.9664901794676242, -0.74828401324927218 },

  /* Computed Parameter: Internal_B_p2
   * Referenced by: '<S9>/Internal'
   */
  { 0.28718916036377862, -0.28718916036377862, 0.28718916036377862,
    -0.28718916036377862 },

  /* Computed Parameter: Internal_C_nt
   * Referenced by: '<S9>/Internal'
   */
  { -0.15970648254359457, -0.39937390426879671, 0.04528269501927671,
    -0.29717034953788274 },

  /* Computed Parameter: Internal_D_f
   * Referenced by: '<S9>/Internal'
   */
  0.17811288654616439,

  /* Computed Parameter: Internal_A_e
   * Referenced by: '<S6>/Internal'
   */
  { -12.69145450508285, -39.002972194385038, 39.002972194385038,
    -12.69145450508285, -19.37982236725966 },

  /* Computed Parameter: Internal_B_i
   * Referenced by: '<S6>/Internal'
   */
  { 2.09465737861089, 2.7750069719632129, -2.8199774424306989 },

  /* Computed Parameter: Internal_C_k
   * Referenced by: '<S6>/Internal'
   */
  { -0.96598215855509351, -7.3070889428965335, -0.61310635190995821 },

  /* Computed Parameter: Internal_D_b
   * Referenced by: '<S6>/Internal'
   */
  0.161818877317664,

  /* Expression: [0 0]
   * Referenced by: '<S7>/No Control'
   */
  { 0.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S7>/Motor Enable'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S7>/LED Colour'
   */
  0.0,

  /* Expression: [2*pi/2048 2*pi/4096]
   * Referenced by: '<S7>/Counts to rads'
   */
  { 0.0030679615757712823, 0.0015339807878856412 },

  /* Expression: pi/6
   * Referenced by: '<Root>/Pitch Reference '
   */
  0.52359877559829882,

  /* Expression: 0.02
   * Referenced by: '<Root>/Pitch Reference '
   */
  0.02,

  /* Expression: pi/4
   * Referenced by: '<Root>/Yaw Reference'
   */
  0.78539816339744828,

  /* Expression: 0.02
   * Referenced by: '<Root>/Yaw Reference'
   */
  0.02,

  /* Computed Parameter: HILInitialize_CKChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIConfiguration
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOWatchdog
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIInitial
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_AOChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_DOChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 0U, 1U, 2U, 3U },

  /* Computed Parameter: HILInitialize_EIQuadrature
   * Referenced by: '<S7>/HIL Initialize'
   */
  4U,

  /* Computed Parameter: HILInitialize_OOChannels
   * Referenced by: '<S7>/HIL Initialize'
   */
  { 11000U, 11001U, 11002U },

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOReset
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOReset
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POStart
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POEnter
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POReset
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_OOReset
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<S7>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOInitial
   * Referenced by: '<S7>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILReadTimebase_Active
   * Referenced by: '<S7>/HIL Read Timebase'
   */
  1,

  /* Computed Parameter: HILWrite_Active
   * Referenced by: '<S7>/HIL Write'
   */
  0
};
