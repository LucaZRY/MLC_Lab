D_1 = ultidyn('D_1',1);
D_2 = ultidyn('D_2',1);
Delta_1 = usample(D_1,1);  
Delta_2 = usample(D_2,1);
% Delta_1 = tf(0);  
% Delta_2 = tf(0);
% % W_I_Pitch = tf(0);
% % W_I_Yaw = tf(0);